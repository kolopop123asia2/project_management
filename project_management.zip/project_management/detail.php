<?php
include './config/database.php';
include './config/baseurl.php';
include './template/header.php';
include './template/navbar.php';

if (!isset($_GET['project_id']) || $_GET['project_id'] == null) {
    echo '<script>window.location.assign("project.php")</script>';
    exit();
}
//ดึงข้อมูลรายละเอียดโปรเจค
$project_id = $_GET['project_id'];
$sql = "SELECT tbl_project.*, tbl_project_type.project_type_id, tbl_project_type.project_type_name
        FROM tbl_project 
        INNER JOIN tbl_project_type ON tbl_project.project_type = tbl_project_type.project_type_id
        WHERE tbl_project.project_id = :project_id AND tbl_project.delete_at IS NULL";
$stmt = $db->prepare($sql);
$stmt->bindParam(':project_id', $project_id, PDO::PARAM_INT);
$stmt->execute();
$project = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$project) {
    echo '<script>window.location.assign("project.php")</script>';
    exit();
}
?>

<header class="site-header d-flex flex-column justify-content-center align-items-center">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-5 col-12">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= $base_url; ?>/index.php">หน้าแรก</a></li>
                        <li class="breadcrumb-item"><a href="<?= $base_url; ?>/project.php">โครงการทั้งหมด</a></li>
                        <li class="breadcrumb-item active" aria-current="page">รายละเอียข้อมูลโครงการ</li>
                    </ol>
                </nav>
                <h2 class="text-white"><?= $project['project_name']; ?></h2>
            </div>
        </div>
    </div>
</header>

<section class="section-padding pt-4">
    <div class="container">
        <div class="col-lg-8 col-12 mx-auto">
            <div class="custom-block custom-block-topics-listing bg-white shadow-lg mt-3 mb-3">
                <div class="row">
                    <div class="col-12 col-lg-4">
                        <img src="<?= $base_url; ?>/covers/<?= $project['project_cover']; ?>" class="img-fluid" alt="">
                    </div>
                    <div class="col-12 col-lg-8">
                        <h6 class="pb-2 text-center">โครงการ <?= $project['project_name']; ?></h6>
                        <p><strong>เจ้าของโครงการ : </strong> <?= $project['project_owner']; ?></p>
                        <p><strong>ประเภทโครงการ : </strong> <?= $project['project_type_name']; ?></p>
                        <p><strong>ปี พ.ศ : </strong> <?= $project['project_year']; ?></p>
                        <div class="row">
                            <?php if (isset($_SESSION['loged_in']) && $_SESSION['loged_in'] == true) : ?>
                                <div class="col-12 text-center">
                                    <a class="custom-btn" href="<?= $base_url; ?>/uploads/<?= $project['project_filename']; ?>" target="_blank"><i class="bi bi-download"></i> ดาวน์โหลดโครงการ (เต็ม)</a>
                                </div>
                                <div class="col-12">
                                    <hr>
                                </div>
                            <?php endif; ?>
                            <div class="col-12">
                                <a class="custom-btn mb-2" href="<?= $base_url; ?>/uploads/<?= $project['project_file_intro']; ?>" target="_blank"><i class="bi bi-eye"></i> บทนำ</a>
                                <?php if (isset($_SESSION['loged_in']) && $_SESSION['loged_in'] == true) : ?>
                                    <a class="custom-btn mb-2" href="<?= $base_url; ?>/uploads/<?= $project['project_file_chapter_1']; ?>" target="_blank"><i class="bi bi-eye"></i> บทที่ 1</a>
                                    <a class="custom-btn mb-2" href="<?= $base_url; ?>/uploads/<?= $project['project_file_chapter_2']; ?>" target="_blank"><i class="bi bi-eye"></i> บทที่ 2</a>
                                    <a class="custom-btn mb-2" href="<?= $base_url; ?>/uploads/<?= $project['project_file_chapter_3']; ?>" target="_blank"><i class="bi bi-eye"></i> บทที่ 3</a>
                                    <a class="custom-btn mb-2" href="<?= $base_url; ?>/uploads/<?= $project['project_file_chapter_4']; ?>" target="_blank"><i class="bi bi-eye"></i> บทที่ 4</a>
                                    <a class="custom-btn mb-2" href="<?= $base_url; ?>/uploads/<?= $project['project_file_chapter_5']; ?>" target="_blank"><i class="bi bi-eye"></i> บทที่ 5</a>
                                <?php endif; ?>
                                <?php if (!isset($_SESSION['loged_in'])) : ?>
                                    <div class="alert alert-secondary mt-1" role="alert">
                                        <em><strong>หมายเหตุ : </strong> สมัครสมาชิกและเข้าสู่ระบบเพื่อดาวน์โหลดหรือดูรายละเอียดเพิ่มเติม</em>
                                    </div>
                                <?php endif;?>
                            </div>

                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

<?php include './template/footer.php'; ?>