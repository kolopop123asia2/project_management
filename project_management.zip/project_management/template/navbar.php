<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="index.html">
            <img src="<?= $base_url; ?>/assets/images/logo.png" style="width: 60px; height: auto;" />
        </a>

        <div class="d-lg-none ms-auto me-4">
            <a href="#top" class="navbar-icon bi-person smoothscroll"></a>
        </div>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-lg-5 me-lg-auto">
                <li class="nav-item">
                    <a class="nav-link bg-blue text-black" href="<?= $base_url; ?>/index.php"><b>หน้าแรก</b></a>
                </li>
                <!-- NO LOGIN -->
                <?php if (!isset($_SESSION['loged_in'])) : ?>
                    <li class="nav-item">
                        <a class="nav-link bg-blue text-black" href="<?= $base_url; ?>/login.php"><b>เข้าสู่ระบบ</b></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link bg-blue text-black" href="<?= $base_url; ?>/register.php"><b>สมัครสมาชิก</b></a>
                    </li>
                <?php endif; ?>
                <!-- ./ NO LOGIN -->

                <?php if (isset($_SESSION['loged_in'])) : ?>
                    <?php if ($_SESSION['role'] == 'admin') : ?>
                        <!-- ADMIN ROLE-->

                        <!-- จัดการโครงการ -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle bg-blue text-black" href="#" id="dropdownProject" role="button" data-bs-toggle="dropdown" aria-expanded="false"><b>จัดการโครงการ</b></a>
                            <ul class="dropdown-menu dropdown-menu-light" aria-labelledby="dropdownProject">
                                <li><a class="nav-link bg-blue text-black dropdown-item" href="<?= $base_url; ?>/admin/project.php"><b>รายการโครงการ</b></a></li>
                                <li><a class="nav-link bg-blue text-black dropdown-item" href="<?= $base_url; ?>/admin/add_project.php"><b>เพิ่มโครงการใหม่</b></a></li>
                                <li><a class="nav-link bg-blue text-black dropdown-item" href="<?= $base_url; ?>/admin/project_type.php"><b>จัดการประเภทโครงการ</b></a></li>
                            </ul>
                        </li>

                        <!-- ADMIN ROLE-->
                    <?php else : ?>
                        <!-- MEMBER ROLE-->
                        <li class="nav-item">
                            <a class="nav-link" href="<?= $base_url; ?>/project.php">ค้นหาเพิ่มเติม</a>
                        </li>
                        <!-- ./ MEMBER ROLE -->
                    <?php endif; ?>
                <?php endif; ?>


                <li class="nav-item">
                    <a class="nav-link bg-blue text-black" href="<?= $base_url; ?>/about.php"><b>เกี่ยวกับฉัน</b></a>
                </li>

            </ul>


            <?php if (isset($_SESSION['loged_in'])) : ?>
                <div class="d-none d-lg-block">
                    <span><?= $_SESSION['name']; ?> (<?= $_SESSION['role']; ?>)</span> &nbsp; <a href="<?= $base_url; ?>/logout.php" class="navbar-icon bi-power smoothscroll"></a>
                </div>
            <?php else : ?>
                <div class="d-none d-lg-block">
                    <a href="<?= $base_url; ?>/login.php" class="navbar-icon bi-person smoothscroll"></a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</nav>