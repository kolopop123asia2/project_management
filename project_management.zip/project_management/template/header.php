<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">

        <title>ระบบค้นหาโครงการ</title>

        <!-- CSS FILES -->        
        <link rel="preconnect" href="https://fonts.googleapis.com">
        
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

        <link href="https://fonts.googleapis.com/css2?family=Kanit&display=swap" rel="stylesheet">
        <link href="<?=$base_url;?>/assets/css/bootstrap.min.css" rel="stylesheet">

        <link href="<?=$base_url;?>/assets/css/bootstrap-icons.css" rel="stylesheet">
        <link href="<?=$base_url;?>/assets/css/custom.css" rel="stylesheet">
        <link href="<?=$base_url;?>/assets/css/templatemo-topic-listing.css" rel="stylesheet">   
        <style>
            *, html, body, p, h1,h2,h3,h4,h5,h6, li, ul, button,a{
                font-family: 'Kanit' !important;
            }
        </style>
        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script> 
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>   
    </head>
<body id="top">