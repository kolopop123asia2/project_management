        <!-- JAVASCRIPT FILES -->
        <script src="<?=$base_url;?>/assets/js/jquery.min.js"></script>
        <script src="<?=$base_url;?>/assets/js/bootstrap.bundle.min.js"></script>
        <script src="<?=$base_url;?>/assets/js/jquery.sticky.js"></script>
        <!-- <script src="<?=$base_url;?>/assets/js/click-scroll.js"></script> -->
        <script src="<?=$base_url;?>/assets/js/custom.js"></script>
        <script src="<?=$base_url;?>/js/function.js"></script>
        <script src="https://kit.fontawesome.com/4bd7f71132.js" crossorigin="anonymous"></script>
    </body>
</html>