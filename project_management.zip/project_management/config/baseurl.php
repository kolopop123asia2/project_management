<?php
	session_start();
	$url = basename($_SERVER['REQUEST_URI']);

	$base_url = "http://127.0.1/project_management";	 

	$page =  basename($_SERVER['PHP_SELF']);
	$pagename = ucwords(str_replace(".","",str_replace("_", " ", $page)));

	if($pagename == "Index"){
	   $pagename = "Home";
	}else{
	   $pagename = $pagename;
	}
	include('database.php');
?>