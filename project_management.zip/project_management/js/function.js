function toast(icon="",title='สำเร็จ', text){
    Swal.fire({
        position: 'top-end',
        icon : icon,
        title : title,
        text : text,
        toast: true,
        timer : 2000,
        showConfirmButton: false
    })
}