<?php
session_start();
include dirname(__DIR__) . '/config/database.php';
if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    http_response_code(404);
    exit();
}
$username = $_POST['username'];
$password = $_POST['password'];
if (!isset($username) || !isset($password)) {
    echo json_encode([
        'status' => false,
        'message' => 'กรุณากรอกชื่อผู้ใช้งานและรหัสผ่าน'
    ]);
    exit();
}

try {
    $hash_password = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $db->prepare("SELECT * FROM tbl_member WHERE username = :username");
    $stmt->bindParam(':username', $username);
    //$stmt->bindParam(':password', $hash_password);
    $stmt->execute();
    $member = $stmt->fetch(PDO::FETCH_ASSOC);

    //มีผู้ใช้งาน usernameนี้
    if ($member) {
        //ตรวจสอบรหัสผ่านที่เข้ารหัสไว้
        if(password_verify($password, $member['password'])){
            $_SESSION['mem_id']=$member['mem_id'];
            $_SESSION['name'] = $member['firstname'].' '.$member['lastname'];
            $_SESSION['loged_in'] = true;
            $_SESSION['role'] = $member['role'];
            echo json_encode([
                'status' => true,
                'message' => 'ยินดีต้อนรับเข้าสู่ระบบค้นหาโครงการต่างๆ'
            ]);
        }else{
            echo json_encode([
                'status' => false,
                'message' => 'รหัสผ่านไม่ถูกต้อง กรุณาตรวจสอบอีกครั้ง'
            ]);
        }
        
        
    } else {
        echo json_encode([
            'status' => false,
            'message' => 'ไม่มีผู้ใช้งานนี้ในระบบ กรุณาตรวจสอบใหม่อีกครั้ง'
        ]);
    }
} catch (PDOException $err) {
    echo json_encode([
        'status' => false,
        'message' => $err->getMessage()
    ]);
    exit();
}
