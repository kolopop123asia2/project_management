<?php
session_start();
include dirname(__DIR__) . '/config/database.php';
if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    http_response_code(404);
    exit();
}
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$username = $_POST['username'];
$password = $_POST['password'];
if (!isset($firstname) || !isset($lastname) || !isset($username) || !isset($password)) {
    echo json_encode([
        'status' => false,
        'message' => 'กรุณากรอกข้อมูลให้ครบถ้วน'
    ]);
    exit();
}
try {

    //check username ซ้ำ
     $stmt = $db->prepare("SELECT COUNT(*) FROM tbl_member WHERE username = :username");
     $stmt->bindParam(':username', $username);
     $stmt->execute();
     $count = $stmt->fetchColumn();
     if ($count > 0) {
         echo json_encode([
            'status' => false,
            'message' => 'ชื่อผู้ใช้งานนี้ถูกใช้งานแล้วกรุณาเปลี่ยนใหม่'
         ]);
         exit();
     }
    
    $hash_password = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $db->prepare("INSERT INTO tbl_member (firstname, lastname, username, password) VALUES (:firstname,:lastname,:username, :password)");
    $stmt->bindParam(':firstname', $firstname);
    $stmt->bindParam(':lastname', $lastname);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $hash_password);
    $stmt->execute();
    echo json_encode([
        'status' => true,
        'message' => 'สมัครสมาชิกสำเร็จ สามารถเข้าสู่ระบบได้ที่หน้า "เข้าสู่ระบบ"'
    ]);exit();
} catch (PDOException $err) {
    echo json_encode([
        'status' => false,
        'message' => $err->getMessage()
    ]);
    exit();
}
