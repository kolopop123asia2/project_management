<?php
include('./config/baseurl.php');
if (isset($_SESSION['loged_in'])) {
    header('Location: index.php');
    exit();
}
include('./template/header.php');
include('./template/navbar.php');
?>

<main style="height: 100%;">
    <section class="timeline-section section-padding" id="login" style="height: 1080px;">
        <div class="section-overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-3"></div>
                <div class="col-lg-6 col-12">
                    <h2 class="text-white mb-4 mt-4 text-center">สมัครสมาชิก</h1>
                        <div class="custom-form">
                            <div class="row">
                                <div class="col-12 col-lg-6">
                                    <div class="form-floating">
                                        <input type="text" name="firstname" id="firstname" class="form-control" placeholder="กรอกชื่อ">
                                        <label for="floatingInput">ชื่อ</label>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6">
                                    <div class="form-floating">
                                        <input type="text" name="lastname" id="lastname" class="form-control" placeholder="กรอกนามสกุล">
                                        <label for="floatingInput">นามสกุล</label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12 col-12">
                                    <div class="form-floating">
                                        <input type="text" name="username" id="username" class="form-control" placeholder="กรอกชื่อผู้ใช้งาน" onkeypress="return (event.charCode >= 65 && event.charCode <= 90) || (event.charCode >= 97 && event.charCode <= 122) || (event.charCode >= 48 && event.charCode <= 57)">
                                        <label for="floatingInput">รหัสนักศึกษา 10 หลัก</label>
                                    </div>
                                    <div class="form-floating">
                                        <input type="password" name="password" id="password" class="form-control" placeholder="กรอกรหัสผ่าน">
                                        <label for="floatingInput">รหัสผ่าน (6 ตัวอักษรขึ้นไป)</label>
                                    </div>
                                    <div class="form-floating">
                                        <input type="password" name="password" id="confirm_password" class="form-control" placeholder="กรอกรหัสผ่าน">
                                        <label for="floatingInput">ยืนยันรหัสผ่าน</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <button type="submit" onclick="register()" class="form-control">สมัครสมาชิก</button>
                                </div>
                            </div>
                        </div>
                </div>

            </div>
        </div>
    </section>
</main>
<script>
    function clearForm(){
        $('#username').val('');
        $('#firstname').val('');
        $('#lastname').val('');
        $('#password').val('');
        $('#confirm_password').val('');
    }
    function register() {
        //ประกาศตัวแปรเก็บข้อมูลโดยว่างจาก id ของ Input ต่างๆ
        const username = $('#username').val();
        const password = $('#password').val();
        const firstname = $('#firstname').val();
        const lastname = $('#lastname').val();
        const confirm_password = $('#confirm_password').val();
        // เช็คค่าว่างของฟอร์ม
        if (firstname=="" || lastname=="" || confirm_password == "" || username == "" || password == "") {
            toast('warning', 'แจ้งเตือน', 'กรุณากรอกชื่อผู้ใช้งานและรหัสผ่านให้ครบถ้วน');
            return false;
        }
        // เช็คจำนวนอักษรรหัสผ่าน
        if(password.length<6){
            toast('warning', 'รหัสผ่านไม่ถูกต้อง','รหัสผ่านจะต้องมี 6 ตัวอักษรขึ้นไป');
            return false;
        }
        // เช็คยืนยันรหัสผ่าน
        if(password != confirm_password){
            toast('warning', 'ยืนยันรหัสผ่านไม่ถูกต้อง','รหัสผ่านและรหัสผ่านยืนยันไม่ตรงกัน กรุณาตรวจสอบให้ถูกต้อง');
            return false;
        }
        $.ajax({
            url : '<?=$base_url;?>/modules/register.php',
            method : 'POST',
            dataType: 'json',
            data : {
                username : username,
                password : password,
                firstname : firstname,
                lastname : lastname
            },
            success : function(res){
                //console.log(res);
                if(res.status){
                    Swal.fire({
                        icon : 'success',
                        title : 'สำเร็จ',
                        text : res.message,
                        showCancelButton : true,
                        confirmButtonText : 'เข้าสู่ระบบ',
                        cancelButtonText : 'ยกเลิก'
                    }).then((result)=>{
                        if(result.isConfirmed){
                            window.location.assign('./login.php');
                            // header('Location: login.php');
                        }
                    })
                    clearForm();
                }else{
                    toast('error','ผิดพลาด', res.message);
                }
            },
            error : function(err){
                //console.log(err);
                toast('error','ผิดพลาด', err.responseText);
            }
        })
    }
</script>
<?php
include('./template/footer.php');
?>