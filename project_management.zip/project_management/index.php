<?php
include_once('./config/baseurl.php');
include './template/header.php';
include './template/navbar.php';
//เรียกข้อมูลประเภทโครงการ
$sql = "SELECT* FROM tbl_project_type WHERE delete_at IS NULL ORDER BY project_type_name ASC";
$stmt = $db->prepare($sql);
$stmt->execute();
$project_type = $stmt->fetchAll(PDO::FETCH_ASSOC);
//check query เพิ่มเติม
@$project_type_id = $_GET['project_type'];
@$project_year = $_GET['project_year'];
$keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';

//เรียกโครงการ
$sql = "SELECT tbl_project.*,
                tbl_project_type.project_type_id, tbl_project_type.project_type_name
        FROM tbl_project
        INNER JOIN tbl_project_type ON tbl_project.project_type = tbl_project_type.project_type_id
        WHERE tbl_project.delete_at IS NULL AND tbl_project.project_name LIKE :keyword ORDER BY tbl_project.create_at DESC
        ";

$stmt = $db->prepare($sql);
$stmt->bindValue(':keyword', '%' . $keyword . '%', PDO::PARAM_STR);
$stmt->execute();
$projects = $stmt->fetchAll(PDO::FETCH_ASSOC);


if ($project_type_id != null) {
    $projects = array_filter($projects, function ($project) use ($project_type_id) {
        return  $project['project_type_id'] == $project_type_id;
    });
}
if ($project_year != null) {
    $projects = array_filter($projects, function ($project) use ($project_year) {
        return  $project['project_year'] == $project_year;
    });
}


?>
<main>
    <section class="hero-section d-flex justify-content-center align-items-center" id="section_1">
        <div class="container">
            <div class="row">

                <div class="col-lg-8 col-12 mx-auto">
                    <h3 class="text-white text-center">เว็บไซต์สืบค้าโครงงานนักเรียนและนักศึกษา</h3>

                    
                    <form method="get" action="project.php" class="custom-form mt-4 pt-2 mb-lg-0 mb-5" role="search">
                        <div class="input-group input-group-lg">
                            <span class="input-group-text bi-search" id="basic-addon1"></span>
                            <input name="keyword" type="search" class="form-control" id="keyword" placeholder="ค้นหาชื่อโครงการที่นี่..." aria-label="Search">
                            <button type="submit" class="form-control"><i class="bi bi-search"></i> ค้นหา</button>
                            <a href="<?=$base_url;?>/project.php" class="btn btn-more">ค้นหาละเอียด</a>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </section>




    <section class="explore-section section-padding" id="section_2">
        <div class="container">

            <div class="col-12 text-center">
                <h2 class="mb-4">10 โครงการล่าสุด</h1>
            </div>
        </div>

        <div class="container-fluid">
            <div class="row">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <?php $i = 0;
                    foreach ($project_type as $item_project_type) : ?>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link <?= $i == 0 ? 'active' : ''; ?>" id="tab-<?= $item_project_type['project_type_id']; ?>" data-bs-toggle="tab" data-bs-target="#tab-pane-<?= $item_project_type['project_type_id']; ?>" type="button" role="tab" aria-controls="design-tab-pane" aria-selected="true"><?= $item_project_type['project_type_name']; ?></button>
                        </li>
                    <?php $i++;
                    endforeach; ?>
                </ul>
            </div>
        </div>

        <div class="container">
            <div class="row">

                <div class="col-12">
                    <div class="tab-content" id="myTabContent">
                        <?php $i = 0;
                        foreach ($project_type as $item_project_type) : ?>
                            <div class="tab-pane fade show <?= $i == 0 ? 'active' : ''; ?>" id="tab-pane-<?= $item_project_type['project_type_id']; ?>" role="tabpanel" aria-labelledby="tab-<?= $item_project_type['project_type_id']; ?>" tabindex="0">
                                <div class="row">
                                    <?php $p = 1;
                                    foreach ($projects as $item_project) : ?>
                                        <?php if ($p <= 10 && $item_project['project_type'] == $item_project_type['project_type_id']) : ?>
                                            <div class="mx-auto">
                                                <div class="custom-block bg-white shadow-lg">
                                                    <a href="<?=$base_url;?>/detail.php?project_id=<?=$item_project['project_id'];?>">
                                                        <div class="d-flex">
                                                            <div>
                                                                <h5 class="mb-2"><?= $item_project['project_name']; ?></h5>

                                                                <p class="mb-0"><strong>เจ้าของโครงการ :</strong> <?=$item_project['project_owner'];?></p>
                                                                <p class="mb-0"><strong>ปี พ.ศ. :</strong> <?=$item_project['project_year'];?></p>
                                                            </div>
                                                        </div>

                                                          </a>
                                                </div>
                                            </div>
                                        <?php $have = true;
                                        endif; ?>
                                    <?php $p++;
                                    endforeach; ?>
                                </div>
                            </div>
                        <?php $i++;
                        endforeach; ?>
                    </div>

                </div>
            </div>
    </section>

</main>

<?php
include_once('./template/footer.php');
?>