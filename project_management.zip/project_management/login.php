<?php
include('./config/baseurl.php');
if (isset($_SESSION['loged_in'])) {
    header('Location: index.php');
    exit();
}
include('./template/header.php');
include('./template/navbar.php');
?>

<main>
    <section class="timeline-section section-padding" id="login" style="height: 1080px;">
        <div class="section-overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-3"></div>
                <div class="col-lg-6 col-12">
                    <h2 class="text-white mb-4 mt-4 text-center">เข้าสู่ระบบ</h1>
                        <div class="custom-form">
                            <div class="row">
                                <div class="col-lg-12 col-12">
                                    <div class="form-floating">
                                        <input type="text" name="username" id="username" class="form-control" placeholder="กรอกชื่อผู้ใช้งาน" autofocus>
                                        <label for="floatingInput">รหัสนักศึกษา 10 หลัก</label>
                                    </div>
                                    <div class="form-floating">
                                        <input type="password" name="password" id="password" class="form-control" placeholder="กรอกรหัสผ่าน">
                                        <label for="floatingInput">รหัสผ่าน</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <button type="submit" onclick="checklogin()" class="form-control">เข้าสู่ระบบ</button>
                                </div>
                            </div>
                        </div>
                </div>

            </div>
        </div>
    </section>
</main>
<script>
    function checklogin() {
        const username = $('#username').val();
        const password = $('#password').val();
        if (username == "" || password == "") {
            toast('warning', 'แจ้งเตือน', 'กรุณากรอกชื่อผู้ใช้งานและรหัสผ่านให้ครบถ้วน');
            return false;
        }
        $.ajax({
            url : '<?=$base_url;?>/modules/checklogin.php',
            dataType: 'json',
            method : 'POST',
            data : {
                username : username,
                password : password
            },
            success : function(res){
                console.log(res);
                if(res.status){
                    toast('success', 'เข้าสู่ระบบสำเร็จ', res.message);
                    setTimeout(()=>{
                        window.location.reload();
                    }, 2000)
                }else{
                    toast('warning', 'ไม่สำเร็จ', res.message);
                }
            }
        })
        
    }
</script>
<?php
include('./template/footer.php');
?>