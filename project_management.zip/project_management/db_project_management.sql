-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 18, 2023 at 10:43 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_project_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_member`
--

CREATE TABLE `tbl_member` (
  `mem_id` int(11) NOT NULL COMMENT 'id ผู้ใช้งาน',
  `firstname` varchar(100) NOT NULL COMMENT 'ชื่อจริง',
  `lastname` varchar(100) NOT NULL COMMENT 'นามสกุล',
  `username` varchar(100) NOT NULL COMMENT 'รหัสนักศักษา 10 หลัก',
  `password` varchar(200) NOT NULL COMMENT 'รหัสผ่านเข้าสู่ระบบ',
  `profile_img` varchar(200) DEFAULT NULL COMMENT 'รูปโปรไฟล์',
  `role` varchar(6) NOT NULL DEFAULT 'member' COMMENT 'สิทธ์การเข้าถึง "member" \r\n "admin"',
  `create_at` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'วันเวลาที่สร้าง'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `tbl_member`
--

INSERT INTO `tbl_member` (`mem_id`, `firstname`, `lastname`, `username`, `password`, `profile_img`, `role`, `create_at`) VALUES
(7, 'admin', '1', 'admin1', '$2y$10$Ts.U1NAy0LMbZJUHqxDtmOoc0n6UxSe26olSoDzXSAimU4h81bRfG', NULL, 'admin', '2023-12-09 01:12:53'),
(8, 'test', 'test', 'test', '$2y$10$7aQPHxRMG5LJ8KJQGCiw7.BGlS2kmhwB.sZAUQ1fW1O3nLI7YzH6q', NULL, 'member', '2023-12-09 01:17:51'),
(9, 'test3', 'test3', 'test3', '$2y$10$CbZ55d421lWOqWi5YIizO.is7dwYVlnLrtePnFo6dAUHzrHkOC6CO', NULL, 'member', '2023-12-09 01:18:35'),
(10, 'member', '1', 'member1', '$2y$10$NqvEiCoMBV3Fnc3AGIFhd.sI/6LuCeHBZnOeLepopya4nZQVwGuRO', NULL, 'member', '2023-12-09 01:19:58'),
(11, 'member', '2', 'member2', '$2y$10$7/002YeWfG9LBNUjf2UnQ.31hD2jml8j/5juX.Ehiq1DlDAYfWUm2', NULL, 'member', '2023-12-09 01:20:37'),
(12, 'member', '4', 'member4', '$2y$10$mHcGTL.V8D36F3DLyn0/sOqhLIUqG0vPWp3XAszTvBre1JxctTMES', NULL, 'member', '2023-12-09 01:21:16');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_project`
--

CREATE TABLE `tbl_project` (
  `project_id` int(11) NOT NULL COMMENT 'ไอดีโครงการ',
  `project_name` varchar(200) NOT NULL COMMENT 'ชื่อโครงการ',
  `project_cover` varchar(200) NOT NULL COMMENT 'รูปหน้าปกโครงการ',
  `project_year` int(4) NOT NULL COMMENT 'ปีของโครงการ',
  `project_type` int(11) NOT NULL COMMENT 'ประเภทโครงการ จากตาราง tbl_project_type',
  `project_owner` varchar(200) NOT NULL COMMENT 'ชื่อเจ้าของโครงการ',
  `project_filename` varchar(200) NOT NULL COMMENT 'ชื่อไฟล์',
  `project_file_intro` varchar(200) NOT NULL,
  `project_file_chapter_1` varchar(200) NOT NULL,
  `project_file_chapter_2` varchar(200) NOT NULL,
  `project_file_chapter_3` varchar(200) NOT NULL,
  `project_file_chapter_4` varchar(200) NOT NULL,
  `project_file_chapter_5` varchar(200) NOT NULL,
  `create_at` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'วันเวลาที่เพิ่มข้อมูล',
  `delete_at` datetime DEFAULT NULL COMMENT 'วันเวลาที่ลบข้อมูล',
  `create_by` int(11) NOT NULL COMMENT 'เพิ่มโดย mem_id',
  `delete_by` int(11) DEFAULT NULL COMMENT 'ลบโดย mem_id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_project_type`
--

CREATE TABLE `tbl_project_type` (
  `project_type_id` int(11) NOT NULL COMMENT 'ไอดีประเภทโครงการ',
  `project_type_name` varchar(200) NOT NULL COMMENT 'ชื่อประเภทโครงการ',
  `create_at` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'วันที่เพิ่มข้อมูล',
  `delete_at` datetime DEFAULT NULL COMMENT 'วันที่ลบข้อมูล (ไม่ได้ลบจริง) เป็นการอัพเดตวันที่ลบข้อมูลแทน'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_member`
--
ALTER TABLE `tbl_member`
  ADD PRIMARY KEY (`mem_id`);

--
-- Indexes for table `tbl_project`
--
ALTER TABLE `tbl_project`
  ADD PRIMARY KEY (`project_id`);

--
-- Indexes for table `tbl_project_type`
--
ALTER TABLE `tbl_project_type`
  ADD PRIMARY KEY (`project_type_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_member`
--
ALTER TABLE `tbl_member`
  MODIFY `mem_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id ผู้ใช้งาน';

--
-- AUTO_INCREMENT for table `tbl_project`
--
ALTER TABLE `tbl_project`
  MODIFY `project_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ไอดีโครงการ';

--
-- AUTO_INCREMENT for table `tbl_project_type`
--
ALTER TABLE `tbl_project_type`
  MODIFY `project_type_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ไอดีประเภทโครงการ';
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
