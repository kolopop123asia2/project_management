<?php
session_start();
include dirname(__DIR__) . '/checkadmin.php';
include dirname(__DIR__) . '/../config/database.php';

try {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Check if the file was uploaded without errors
        if ((isset($_FILES["project_file"]) && $_FILES["project_file"]["error"] == UPLOAD_ERR_OK) &&
            (isset($_FILES["project_intro"]) && $_FILES["project_intro"]["error"] == UPLOAD_ERR_OK) &&
            (isset($_FILES["project_chapter_1"]) && $_FILES["project_chapter_1"]["error"] == UPLOAD_ERR_OK) &&
            (isset($_FILES["project_chapter_2"]) && $_FILES["project_chapter_2"]["error"] == UPLOAD_ERR_OK)  &&
            (isset($_FILES["project_chapter_3"]) && $_FILES["project_chapter_3"]["error"] == UPLOAD_ERR_OK)  &&
            (isset($_FILES["project_chapter_4"]) && $_FILES["project_chapter_4"]["error"] == UPLOAD_ERR_OK)  &&
            (isset($_FILES["project_chapter_5"]) && $_FILES["project_chapter_5"]["error"] == UPLOAD_ERR_OK) &&
            (isset($_FILES["project_cover"]) && $_FILES["project_cover"]["error"] == UPLOAD_ERR_OK)
        ) {
            $project_name = $_POST['project_name'];
            $project_type = $_POST['project_type'];
            $project_owner = $_POST['project_owner'];
            $project_year = $_POST['project_year'];
            $mem_id = $_SESSION['mem_id'];
            if (
                !isset($project_name) || !isset($project_type) || !isset($project_owner) || !isset($project_year) ||
                $project_name == null || $project_type == null || $project_owner == null || $project_year == null
            ) {
                echo json_encode([
                    'status' => false,
                    'message' => 'กรุณากรอกข้อมูลให้ครบถ้วน'
                ]);
                exit();
            }
            //pdf file
            $file_name = date("Y-m-d-") . time() . $_FILES["project_file"]["name"] . '.' . pathinfo($_FILES['project_file']['name'])['extension'];
            $file_temp = $_FILES["project_file"]["tmp_name"];
            //cover image
            $file_name_cover = date("Y-m-d-") . time() . $_FILES["project_cover"]["name"] . '.' . pathinfo($_FILES['project_cover']['name'])['extension'];
            $file_temp_cover = $_FILES["project_cover"]["tmp_name"];

            //intro
            $file_name_intro = date("Y-m-d-") . time() . $_FILES["project_intro"]["name"] . '.' . pathinfo($_FILES['project_intro']['name'])['extension'];
            $file_temp_intro = $_FILES["project_intro"]["tmp_name"];
            $file_name_chapter_1 = date("Y-m-d-") . time() . $_FILES["project_chapter_1"]["name"] . '.' . pathinfo($_FILES['project_chapter_1']['name'])['extension'];
            $file_temp_chapter_1 = $_FILES["project_chapter_1"]["tmp_name"];
            $file_name_chapter_2 = date("Y-m-d-") . time() . $_FILES["project_chapter_2"]["name"] . '.' . pathinfo($_FILES['project_chapter_2']['name'])['extension'];
            $file_temp_chapter_2 = $_FILES["project_chapter_2"]["tmp_name"];
            $file_name_chapter_3 = date("Y-m-d-") . time() . $_FILES["project_chapter_3"]["name"] . '.' . pathinfo($_FILES['project_chapter_3']['name'])['extension'];
            $file_temp_chapter_3 = $_FILES["project_chapter_3"]["tmp_name"];
            $file_name_chapter_4 = date("Y-m-d-") . time() . $_FILES["project_chapter_4"]["name"] . '.' . pathinfo($_FILES['project_chapter_4']['name'])['extension'];
            $file_temp_chapter_4 = $_FILES["project_chapter_4"]["tmp_name"];
            $file_name_chapter_5 = date("Y-m-d-") . time() . $_FILES["project_chapter_5"]["name"] . '.' . pathinfo($_FILES['project_chapter_5']['name'])['extension'];
            $file_temp_chapter_5 = $_FILES["project_chapter_5"]["tmp_name"];

            $upload_directory = dirname(__DIR__);
            $directory_cover = dirname(__DIR__);
            $file_path = './../uploads/' . $file_name;
            $file_path_intro = './../uploads/' . $file_name_intro;
            $file_path_chapter_1 = './../uploads/' . $file_name_chapter_1;
            $file_path_chapter_2 = './../uploads/' . $file_name_chapter_2;
            $file_path_chapter_3 = './../uploads/' . $file_name_chapter_3;
            $file_path_chapter_4 = './../uploads/' . $file_name_chapter_4;
            $file_path_chapter_5 = './../uploads/' . $file_name_chapter_5;
            $file_path_cover = './../covers/' . $file_name_cover;
            //project_filename
            move_uploaded_file($file_temp, dirname(__DIR__) . $file_path);
            //intro
            move_uploaded_file($file_temp_intro, dirname(__DIR__) . $file_path_intro);
            move_uploaded_file($file_temp_chapter_1, dirname(__DIR__) . $file_path_chapter_1);
            move_uploaded_file($file_temp_chapter_2, dirname(__DIR__) . $file_path_chapter_2);
            move_uploaded_file($file_temp_chapter_3, dirname(__DIR__) . $file_path_chapter_3);
            move_uploaded_file($file_temp_chapter_4, dirname(__DIR__) . $file_path_chapter_4);
            move_uploaded_file($file_temp_chapter_5, dirname(__DIR__) . $file_path_chapter_5);

            move_uploaded_file($file_temp_cover, dirname(__DIR__) . $file_path_cover);

            $stmt = $db->prepare("INSERT INTO tbl_project (project_name, project_cover, project_year, project_type, project_owner, project_filename, project_file_intro, project_file_chapter_1, project_file_chapter_2, project_file_chapter_3, project_file_chapter_4, project_file_chapter_5, create_by) 
                                    VALUES (:project_name, :project_cover, :project_year, :project_type, :project_owner, :project_filename, :project_file_intro, :project_file_chapter_1, :project_file_chapter_2, :project_file_chapter_3, :project_file_chapter_4, :project_file_chapter_5, :create_by)");
            $stmt->bindParam(':project_name', $project_name);
            $stmt->bindParam(':project_cover', $file_name_cover);
            $stmt->bindParam(':project_type', $project_type);
            $stmt->bindParam(':project_year', $project_year);
            $stmt->bindParam(':project_owner', $project_owner);
            $stmt->bindParam(':project_filename', $file_name);
            $stmt->bindParam(':project_file_intro', $file_name_intro);
            $stmt->bindParam(':project_file_chapter_1', $file_name_chapter_1);
            $stmt->bindParam(':project_file_chapter_2', $file_name_chapter_2);
            $stmt->bindParam(':project_file_chapter_3', $file_name_chapter_3);
            $stmt->bindParam(':project_file_chapter_4', $file_name_chapter_4);
            $stmt->bindParam(':project_file_chapter_5', $file_name_chapter_5);
            $stmt->bindParam(':create_by', $mem_id);
            $stmt->execute();

            echo json_encode([
                'status' => true,
                'message' => 'เพิ่มข้อมูลโครงการเรียบร้อยแล้ว'
            ]);
            exit();
        } else {
            echo json_encode([
                'status' => false,
                'message' => 'กรุณาแนบไฟล์เอกสาร PDF และ รูปภาพ COVER ของโครงการ'
            ]);
            exit();
        }
    }
} catch (PDOException $e) {
    // Handle database connection or query errors
    echo "Error: " . $e->getMessage();
}
