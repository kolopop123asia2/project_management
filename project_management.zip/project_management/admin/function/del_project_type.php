<?php
session_start();
include dirname(__DIR__) . '/checkadmin.php';
include dirname(__DIR__) . '/../config/database.php';
if($_SERVER['REQUEST_METHOD']!='DELETE'){
    http_response_code(404);exit();
}
try{
    $project_type_id = $_GET['project_type_id'];
    if(!isset($project_type_id) || $project_type_id == null){
        echo json_encode([
            'status' => false,
            'message' => 'ไม่พบไอดีที่ต้องการลบ'
        ]);
        exit();
    }
    $project_type_id = intval($project_type_id);
    $datenow = date("Y-m-d H:i:s");
    $sql = "UPDATE tbl_project_type SET delete_at = :datenow  WHERE project_type_id=:project_type_id";
    $stmt = $db->prepare($sql);
    $stmt->bindParam('datenow', $datenow);
    $stmt->bindParam('project_type_id', $project_type_id);
    $stmt->execute();
    echo json_encode([
        'status' => true,
        'message' => "ลบประเภทโครงการเรียบร้อยแล้ว"
    ]);
    exit();
}catch(PDOException $err){
    echo json_encode([
        'status' => false,
        'message' => $err->getMessage()
    ]);
    exit();
}
