<?php
error_reporting(E_ALL & ~E_NOTICE); //close error show in page
session_start();
include dirname(__DIR__) . '/checkadmin.php';
include dirname(__DIR__) . '/../config/database.php';

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    http_response_code(404);
    exit();
}
try {
    $project_type_id = $_POST['project_type_id'];
    $project_type_name = $_POST['project_type_name'];
    if (!isset($project_type_name) || $project_type_name == null) {
        echo json_encode([
            'status' => false,
            'message' => 'กรุณากรอกชื่อประเภทโครงการ'
        ]);
        exit();
    }
    if(!isset($project_type_id) || $project_type_id == null){
        echo json_encode([
            'status' => false,
            'message' => 'ไม่พบไอดีที่ต้องการแก้ไข'
        ]);exit();
    }

    //check username ซ้ำ
    $stmt = $db->prepare("SELECT COUNT(*) FROM tbl_project_type WHERE project_type_name = :project_type_name");
    $stmt->bindParam(':project_type_name', $project_type_name);
    $stmt->execute();
    $count = $stmt->fetchColumn();
    if ($count > 0) {
        echo json_encode([
            'status' => false,
            'message' => 'ชื่อโครงการนี้มีแล้วในฐานข้อมูล'
        ]);
        exit();
    }
    $sql = "UPDATE tbl_project_type SET project_type_name = :project_type_name  WHERE project_type_id = :project_type_id";
    $stmt = $db->prepare($sql);
    $stmt->bindParam(':project_type_id', $project_type_id);
    $stmt->bindParam(':project_type_name', $project_type_name);
    $stmt->execute();
    echo json_encode([
        'status' => true,
        'message' => "แก้ไขประเภทโครงการเรียบร้อยแล้ว"
    ]);
    exit();
} catch (PDOException $err) {
    echo json_encode([
        'status' => false,
        'message' => $err->getMessage()
    ]);
    exit();
}