<?php

session_start();
include dirname(__DIR__) . '/checkadmin.php';
include dirname(__DIR__) . '/../config/database.php';
try {
    if ($_SERVER['REQUEST_METHOD'] != 'DELETE') {
        http_response_code(404);
        exit();
    }

    //ดึงข้อมูลโปรเจคเดิม
    if (!isset($_GET['project_id']) || $_GET['project_id'] == null) {
        echo json_encode([
            'status' => false,
            'message' => 'ไม่พบไอดีโครงการ'
        ]);
        exit();
    } else {
        $project_id = $_GET['project_id'];
        $sql = "SELECT* FROM tbl_project WHERE project_id = :project_id";
        $stmt = $db->prepare($sql);
        $stmt->bindParam(':project_id', $project_id, PDO::PARAM_INT);
        $stmt->execute();
        $project = $stmt->fetch(PDO::FETCH_ASSOC);

        if(!$project){
            echo json_encode([
                'status'=>false,
                'message' => 'ไม่พบรายการโครงการนี้'
            ]);exit();
        }
        $datenow = date("Y-m-d H:i:s");
        $mem_id = $_SESSION['mem_id'];

        $sql = "UPDATE tbl_project SET delete_at=:delete_at, delete_by=:delete_by WHERE project_id=:project_id";
        $stmt = $db->prepare($sql);
        $stmt->bindParam(":delete_at", $datenow);
        $stmt->bindParam(':delete_by', $mem_id);
        $stmt->bindParam(':project_id', $project['project_id']);
        $stmt->execute();
        //ลบไฟล์
        $directory = dirname(__DIR__);
        //ลบรูปภาพ
        if (file_exists($directory . './../covers/' . $project['project_cover'])) {
            unlink($directory . './../covers/' . $project['project_cover']);
        }
        //ลบไฟล์ pdf
        if (file_exists($directory.'./../uploads/' . $project['project_filename'])) {
            unlink($directory.'./../uploads/' . $project['project_filename']);
        }
        echo json_encode([
            'status'=> true,
            'message' => "ลบข้อมูลโครงการเรียบร้อยแล้ว"
        ]);exit();
    }
} catch (PDOException $err) {
    echo json_encode([
        'status'=> false,
        'message' => $err->getMessage()
    ]);exit();
}
