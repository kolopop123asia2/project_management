<?php
include dirname(__DIR__) . '/config/database.php';
include dirname(__DIR__) . './config/baseurl.php';
//checklogin
if (!$_SESSION['loged_in']) {
    header('Location: ' . $base_url . 'login.php');
}
//checkadmin
include('checkadmin.php');
include dirname(__DIR__) . './template/header.php';
include dirname(__DIR__) . './template/navbar.php';
//เรียกข้อมูลประเภทโครงการ
$sql = "SELECT* FROM tbl_project_type WHERE delete_at IS NULL ORDER BY project_type_name ASC";
$stmt = $db->prepare($sql);
$stmt->execute();
$project_type = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!isset($_GET['project_id']) || $_GET['project_id'] == null) {
    header('Location : project.php');
    exit();
}

//ดึงข้อมูลรายละเอียดโปรเจค
$project_id = $_GET['project_id'];
$sql = "SELECT tbl_project.*, tbl_project_type.project_type_id, tbl_project_type.project_type_name
        FROM tbl_project 
        INNER JOIN tbl_project_type ON tbl_project.project_type = tbl_project_type.project_type_id
        WHERE tbl_project.project_id = :project_id AND tbl_project.delete_at IS NULL";
$stmt = $db->prepare($sql);
$stmt->bindParam(':project_id', $project_id, PDO::PARAM_INT);
$stmt->execute();
$project = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$project) {
    echo '<script>window.location.assign("project.php")</script>';
    exit();
}
?>

<header class="site-header d-flex flex-column justify-content-center align-items-center">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-5 col-12">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= $base_url; ?>/index.php">หน้าแรก</a></li>
                        <li class="breadcrumb-item active" aria-current="page">รายละเอียข้อมูลโครงการ</li>
                    </ol>
                </nav>
                <h2 class="text-white">รายละเอียดโครงการ</h2>
            </div>
        </div>
    </div>
</header>

<section class="section-padding pt-4">
    <div class="container">
        <div class="col-lg-8 col-12 mx-auto">
            <div class="custom-block custom-block-topics-listing bg-white shadow-lg mt-3 mb-3">
                <div class="row mb-3">
                    <div class="col-12 mx-auto text-center">
                        <h6>รายละเอียด/แก้ไขโครงการ</h6>
                    </div>
                </div>
                <form method="post" enctype="multipart/form-data" id="formProject">
                    <div class="custom-form">
                        <div class="row">
                            <div class="col-12">
                                <div class="form-floating">
                                    <input type="text" value="<?= $project['project_name']; ?>" name="project_name" id="project_name" class="form-control" placeholder="กรอกชื่อโครงการ">
                                    <label for="floatingInput">ชื่อโครงการ</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <input type="text" value="<?= $project['project_name']; ?>" name="project_owner" id="project_owner" class="form-control" placeholder="กรอกชื่อโครงการ">
                                    <label for="floatingInput">ชื่อเจ้าของโครงการ</label>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="form-floating">
                                    <select name="project_type" class="form-control">
                                        <option value="">เลือกประเภทโครงการ</option>
                                        <?php foreach ($project_type as $item) : ?>
                                            <option value="<?= $item['project_type_id']; ?>" <?= $project['project_type'] == $item['project_type_id'] ? 'selected' : ''; ?>><?= $item['project_type_name']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <label for="floatingInput">ประเภทโครงการ</label>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="form-floating">
                                    <select name="project_year" class="form-control" id="project_year">
                                        <option value="">ปี พ.ศ</option>
                                        <?php for ($i = 2540; $i <= intval(date("Y")) + 543; $i++) : ?>
                                            <option value="<?= $i; ?>" <?= $i == $project['project_year'] ? 'selected' : ''; ?>>
                                                <?= $i; ?>
                                            </option>
                                        <?php endfor; ?>
                                    </select>
                                    <label for="floatingInput">ปีของโครงการ</label>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <hr />
                                <h6 class="text-center">รูปหน้าปกโครงการ <small style="font-size: 14px">(เป็นไฟล์นามสกุล .png .jpg เท่านั้น)</small></h6>
                                <div class="row">
                                    <div class="pt-2 col-12 col-lg-9">
                                        <input type="file" name="project_cover" accept="image/png,image/jpg,image/jpeg" id="project_cover" class="form-control w-100">
                                    </div>
                                    <div class="pt-2 col-12 col-lg-3">
                                        <button type="button" class="btn btn-default w-100" data-bs-toggle="modal" data-bs-target="#previewImage"><i class="bi bi-zoom-in"></i> ดูรูปภาพ</button>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-12">
                                <hr />
                                <h6 class="text-center">แนบไฟล์โครงการ <small style="font-size: 14px">(เป็นไฟล์นามสกุล .pdf เท่านั้น)</small></h6>
                                <div class="row">
                                    <div class="col-12"><label class="pl-1">ไฟล์ต้นฉบับ :</label></div>
                                    <div class="pt-2 col-12 col-lg-9">
                                        <input type="file" name="project_file" accept="application/pdf" id="project_file" class="form-control">
                                    </div>
                                    <div class="pt-2 col-12 col-lg-3">
                                        <a target="_blank" href="<?= $base_url; ?>/uploads/<?= $project['project_filename']; ?>" class="btn btn-default w-100"><i class="bi bi-filetype-pdf"></i> เปิดไฟล์</a>
                                    </div>
                                </div>

                                <!-- บทนำ -->
                                <div class="row">
                                    <div class="col-12"><label class="pl-1">บทนำ :</label></div>
                                    <div class="pt-2 col-12 col-lg-9">
                                        <input type="file" name="project_file_intro" accept="application/pdf" id="project_file_intro" class="form-control">
                                    </div>
                                    <div class="pt-2 col-12 col-lg-3">
                                        <a target="_blank" href="<?= $base_url; ?>/uploads/<?= $project['project_file_intro']; ?>" class="btn btn-default w-100"    ><i class="bi bi-filetype-pdf"></i> เปิดไฟล์</a>
                                    </div>
                                </div>
                                <!-- บทที่ 1 -->
                                <div class="row">
                                    <div class="col-12"><label class="pl-1">บทที่ 1 :</label></div>
                                    <div class="pt-2 col-12 col-lg-9">
                                        <input type="file" name="project_file_chapter_1" accept="application/pdf" id="project_file_chapter_1" class="form-control">
                                    </div>
                                    <div class="pt-2 col-12 col-lg-3">
                                        <a target="_blank" href="<?= $base_url; ?>/uploads/<?= $project['project_file_chapter_1']; ?>" class="btn btn-default w-100"><i class="bi bi-filetype-pdf"></i> เปิดไฟล์</a>
                                    </div>
                                </div>
                                <!-- บทที่ 2 -->
                                <div class="row">
                                    <div class="col-12"><label class="pl-1">บทที่ 2 :</label></div>
                                    <div class="pt-2 col-12 col-lg-9">
                                        <input type="file" name="project_file_chapter_2" accept="application/pdf" id="project_file_chapter_2" class="form-control">
                                    </div>
                                    <div class="pt-2 col-12 col-lg-3">
                                        <a target="_blank" href="<?= $base_url; ?>/uploads/<?= $project['project_file_chapter_2']; ?>" class="btn btn-default w-100"><i class="bi bi-filetype-pdf"></i> เปิดไฟล์</a>
                                    </div>
                                </div>
                                <!-- บทที่ 3 -->
                                <div class="row">
                                    <div class="col-12"><label class="pl-1">บทที่ 3:</label></div>
                                    <div class="pt-2 col-12 col-lg-9">
                                        <input type="file" name="project_file_chapter_3" accept="application/pdf" id="project_file_chapter_3" class="form-control">
                                    </div>
                                    <div class="pt-2 col-12 col-lg-3">
                                        <a target="_blank" href="<?= $base_url; ?>/uploads/<?= $project['project_file_chapter_3']; ?>" class="btn btn-default w-100"><i class="bi bi-filetype-pdf"></i> เปิดไฟล์</a>
                                    </div>
                                </div>
                                <!-- บทที่ 4 -->
                                <div class="row">
                                    <div class="col-12"><label class="pl-1">บทที่ 4 :</label></div>
                                    <div class="pt-2 col-12 col-lg-9">
                                        <input type="file" name="project_file_chapter_4" accept="application/pdf" id="project_file_chapter_4" class="form-control">
                                    </div>
                                    <div class="pt-2 col-12 col-lg-3">
                                        <a target="_blank" href="<?= $base_url; ?>/uploads/<?= $project['project_file_chapter_4']; ?>" class="btn btn-default w-100"><i class="bi bi-filetype-pdf"></i> เปิดไฟล์</a>
                                    </div>
                                </div>
                                <!-- บทที่ 5 -->
                                <div class="row">
                                    <div class="col-12"><label class="pl-1">บทที่ 5 :</label></div>
                                    <div class="pt-2 col-12 col-lg-9">
                                        <input type="file" name="project_file_chapter_5" accept="application/pdf" id="project_file_chapter_5" class="form-control">
                                    </div>
                                    <div class="pt-2 col-12 col-lg-3">
                                        <a target="_blank" href="<?= $base_url; ?>/uploads/<?= $project['project_file_chapter_5']; ?>" class="btn btn-default w-100"><i class="bi bi-filetype-pdf"></i> เปิดไฟล์</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <button type="submit" class="form-control">บันทึกข้อมูล</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<!-- modal preview image -->
<!-- Modal -->
<div class="modal fade" id="previewImage" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">รูปภาพหน้าปกโครงการ</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <img src="<?= $base_url; ?>/covers/<?= $project['project_cover']; ?>" class="img-responsive w-100" />
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ปิด</button>
            </div>
        </div>
    </div>
</div>
<script>
    $('#formProject').on('submit', function(e) {
        e.preventDefault();
        Swal.fire({
            icon: 'warning',
            title: 'อัพเดตข้อมูล',
            text: 'ต้องการอัพเดตแก้ไขข้อมูลโครงการนี้?',
            showCancelButton: true,
            confirmButtonText: 'ตกลง',
            cancelButtonText: 'ยกเลิก'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: "POST",
                    url: "./function/update_project.php?project_id=<?= $project['project_id']; ?>", // Replace with your PHP script URL
                    data: new FormData(this),
                    dataType: 'JSON',
                    contentType: false,
                    processData: false,
                    success: function(res) {
                        console.log(res);
                        if (res.status) {
                            toast('success', 'สำเร็จ', res.message);
                            setTimeout(() => {
                                window.location.assign('project.php');
                            }, 2000);
                        } else {
                            toast('warning', 'แจ้งเตือน', res.message);
                        }

                    },
                    error: function(err) {
                        console.log("Error: " + err.responseText);
                        toast('error', 'ผิดพลาด', err.responseText);
                    }
                });
            }
        })

    })
</script>
<?php include dirname(__DIR__) . './template/footer.php'; ?>