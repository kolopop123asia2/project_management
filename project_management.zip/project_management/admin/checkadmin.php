<?php
if($_SESSION['role']!="admin"){
    header('Location: '.$base_url.'/index.php');
}
?>