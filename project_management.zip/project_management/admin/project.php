<?php
include dirname(__DIR__) . '/config/database.php';
include dirname(__DIR__) . './config/baseurl.php';
//checklogin
if (!$_SESSION['loged_in']) {
    header('Location: ' . $base_url . 'login.php');
}
//checkadmin
include('checkadmin.php');
include dirname(__DIR__) . './template/header.php';
include dirname(__DIR__) . './template/navbar.php';
//เรียกข้อมูลประเภทโครงการ
$sql = "SELECT* FROM tbl_project_type WHERE delete_at IS NULL ORDER BY project_type_name ASC";
$stmt = $db->prepare($sql);
$stmt->execute();
$project_type = $stmt->fetchAll(PDO::FETCH_ASSOC);
//check query เพิ่มเติม
@$project_type_id = $_GET['project_type'];
@$project_year = $_GET['project_year'];
$keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';

//เรียกโครงการ
$sql = "SELECT tbl_project.*,
                tbl_project_type.project_type_id, tbl_project_type.project_type_name
        FROM tbl_project
        INNER JOIN tbl_project_type ON tbl_project.project_type = tbl_project_type.project_type_id
        WHERE tbl_project.delete_at IS NULL AND tbl_project.project_name LIKE :keyword ORDER BY tbl_project.create_at DESC
        ";

$stmt = $db->prepare($sql);
$stmt->bindValue(':keyword', '%' . $keyword . '%', PDO::PARAM_STR);
$stmt->execute();
$projects = $stmt->fetchAll(PDO::FETCH_ASSOC);


if ($project_type_id != null) {
    $projects = array_filter($projects, function ($project) use ($project_type_id) {
        return  $project['project_type_id'] == $project_type_id;
    });
}
if ($project_year != null) {
    $projects = array_filter($projects, function ($project) use ($project_year) {
        return  $project['project_year'] == $project_year;
    });
}
?>
<header class="site-header d-flex flex-column justify-content-center align-items-center">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-5 col-12">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= $base_url; ?>/index.php">หน้าแรก</a></li>
                        <li class="breadcrumb-item active" aria-current="page">จัดการโครงการทั้งหมด</li>
                    </ol>
                </nav>
                <h2 class="text-white">จัดการโครงการทั้งหมด</h2>
            </div>
        </div>
    </div>
</header>

<section class="section-padding pt-4">
    <div class="container">
    <form action="project.php" method="GET">
        <div class="row mb-2 custom-form">
            <div class="col-12 col-lg-4">
                <div class="form-floating">
                    <input name="keyword" type="text" id="project_name" class="form-control" placeholder="ค้นหาโครงการ" />
                    <label for="floatingInput">ชื่อโครงการ</label>
                </div>
            </div>
            <div class="col-12 col-lg-2">
                <div class="form-floating">
                    <select name="project_type" class="form-control">
                        <option value="">เลือกประเภทโครงการ</option>
                        <?php foreach ($project_type as $item) : ?>
                            <option value="<?= $item['project_type_id']; ?>" <?= $item['project_type_id'] == $project_type_id ?'selected' : ''; ?>><?= $item['project_type_name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <label for="floatingInput">ประเภทโครงการ</label>
                </div>
            </div>
            <div class="col-12 col-lg-2">
                <div class="form-floating">
                    <select name="project_year" class="form-control" id="project_year">
                        <option value="">ปี พ.ศ</option>
                        <?php for ($i = 2540; $i <= intval(date("Y")) + 543; $i++) : ?>
                            <option value="<?= $i; ?>" <?=$project_year == $i ? 'selected' : ''; ?>><?= $i; ?></option>
                        <?php endfor; ?>
                    </select>
                    <label for="floatingInput">ปีของโครงการ</label>
                </div>
            </div>
            <div class="col-12 col-lg-2">
                <button type="submit" class="btn custom-btn"><i class="bi bi-search"></i> ค้นหา</button>
            </div>
            <div class="col-12 col-lg-2">
                <a href="./add_project.php" class="btn custom-btn" data-bs-toggle="modal"><i class="bi bi-plus"></i>เพิ่มโครงการ</a>
            </div>
        </div>
    </form>
        <?php if (count($projects) > 0) : ?>
            <div class="row pt-2">
                <?php foreach ($projects as $item_project) : ?>
                    <div class="mx-auto">
                        <div class="custom-block custom-block-topics-listing bg-white shadow-lg mb-5">
                            <div class="d-flex">
                                  <div class="custom-block-topics-listing-info d-flex">
                                    <div>
                                        <h5 class="mb-2"><?= $item_project['project_name']; ?></h5>
                                        <p class="mb-0"><strong>เจ้าของโปรเจค : </strong><?= $item_project['project_owner']; ?></p>
                                        <p class="mb-0"><strong>ปี พ.ศ. : </strong><?= $item_project['project_year']; ?></p>
                                        <a href="project_detail.php?project_id=<?= $item_project['project_id']; ?>" class="btn custom-btn mt-3 mt-lg-4"><i class="bt bi-pencil"></i>รายละเอียด/แก้ไข</a>
                                        <button class="btn btn-danger btn-lg mt-3 mt-lg-4" onclick="delProject(<?= $item_project['project_id']; ?>)">
                                            <i class="bi bi-trash"></i> ลบ
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else : ?>
            <div class="row">
                <div class="col-lg-12 col-12 mx-auto">
                    <div class="custom-block custom-block-topics-listing bg-white shadow-lg mt-3 mb-3">
                        <div class="text-center">
                            <div class="pt-2">
                                <p>ไม่มีโครงการ</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif ?>
    
</section>

<script>
    function delProject(project_id) {
        Swal.fire({
            icon: 'warning',
            title: 'ลบโครงการ',
            text: 'ต้องการลบโครงการนี้?',
            showCancelButton: true,
            confirmButtonText: 'ตกลง',
            cancelButtonText: 'ยกเลิก'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: `./function/del_project.php?project_id=${project_id}`,
                    method: 'DELETE',
                    dataType: 'JSON',
                    success: function(res) {
                        console.log(res);
                        if (res.status) {
                            toast('success', 'ลบสำเร็จ', res.message);
                            setTimeout(() => {
                                window.location.reload();
                            }, 2000);
                        } else {
                            toast('error', 'ไม่สำเร็จ', res.message);
                        }
                    }
                })
            }
        })
    }
</script>
<?php include dirname(__DIR__) . './template/footer.php'; ?>