<?php
include dirname(__DIR__) . '/config/database.php';
include dirname(__DIR__) . './config/baseurl.php';
//checklogin
if (!$_SESSION['loged_in']) {
    header('Location: ' . $base_url . 'login.php');
}
//checkadmin
include('checkadmin.php');
include dirname(__DIR__) . './template/header.php';
include dirname(__DIR__) . './template/navbar.php';

//เรียกข้อมูลจากฐานข้อมูล
$sql = "SELECT * FROM tbl_project_type WHERE delete_at IS NULL ORDER BY create_at DESC";
$stmt = $db->prepare($sql);
$stmt->execute();
$project_type = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<header class="site-header d-flex flex-column justify-content-center align-items-center">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-5 col-12">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= $base_url; ?>/index.php">หน้าแรก</a></li>
                        <li class="breadcrumb-item active" aria-current="page">จัดการประเภทโครงการ</li>
                    </ol>
                </nav>
                <h2 class="text-white">จัดการประเภทโครงการ</h2>
            </div>
        </div>
    </div>
</header>

<section class="section-padding pt-4">
    <div class="container">
        <div class="row mb-2">
            <div class="col-12">
                <button class="btn custom-btn" data-bs-toggle="modal" onclick="openModalAddProjectType()"><i class="bi bi-plus"></i>เพิ่มประเภทโครงการ</button>
            </div>
        </div>
        <?php if (count($project_type) > 0) : ?>
            <div class="row">
                <?php foreach ($project_type as $item_project_type) : ?>
                    <div class="col-lg-12 col-12 mx-auto">
                        <div class="custom-block custom-block-topics-listing bg-white shadow-lg mt-3 mb-3">
                            <div class="d-flex">
                                <div class="pt-2">
                                    <h6><?= $item_project_type['project_type_name']; ?></h6>
                                </div>
                                <div class="ms-auto">
                                    <button class="btn btn-primary" onclick="openModalEditProjectType(<?=$item_project_type['project_type_id'];?>, '<?=$item_project_type['project_type_name'];?>')"><i class="bt bi-pencil"></i> แก้ไข</button>
                                    <button class="btn btn-danger" onclick="delProjectType(<?=$item_project_type['project_type_id'];?>)">
                                        <i class="bi bi-trash"></i> ลบ
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else : ?>
            <div class="row">
                <div class="col-lg-12 col-12 mx-auto">
                    <div class="custom-block custom-block-topics-listing bg-white shadow-lg mt-3 mb-3">
                        <div class="text-center">
                            <div class="pt-2">
                                <p>ไม่มีประเภทโครงการ</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif ?>
</section>


<!-- modal add -->
<div class="modal fade" id="modalProjectType" tabindex="-1" aria-labelledby="exampleModalLabel" data-bs-backdrop="static" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="modalProjectTypeTitle">เพิ่มประเภทโครงการ</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="project_type_id"/>
                <div class="custom-form">
                    <div class="row">
                        <div class="col-12">
                            <div class="form-floating">
                                <input type="text" id="project_type_name" class="form-control" placeholder="กรอกชื่อประเภทโครงการ" autofocus>
                                <label for="floatingInput">ชื่อประเภทโครงการ</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer custom-form">
                <button type="button" onclick="save()" class="btn btn-primary">บันทึก</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ปิด</button>
            </div>
        </div>
    </div>
</div>


<script>
    var mode ="add";
    function clearForm() {
        $('#project_type_name').val('');
        $('#project_type_id').val('');
    }

    function openModalAddProjectType() {
        mode = "add";
        clearForm();
        $('#modalProjectTypeTitle').html('เพิ่มประเภทโครงการ');
        $('#modalProjectType').modal('show');
    }
    function save(){
        if(mode=='add'){
            addProjectType();
        }else if(mode=='edit'){
            updateProjectType();
        }
    }
    function openModalEditProjectType(project_type_id, project_type_name){
        mode = "edit";
        clearForm();
        $('#modalProjectTypeTitle').html('แก้ไขประเภทโครงการ');
        $('#project_type_id').val(project_type_id);
        $('#project_type_name').val(project_type_name);
        $('#modalProjectType').modal('show');
    }
    function updateProjectType(){
        const project_type_id = $('#project_type_id').val();
        const project_type_name = $('#project_type_name').val();
        if (project_type_name == "" || project_type_id=="") {
            toast('warning', 'แจ้งเตือน', 'กรุณากรอกชื่อประเภทโครงการ');
            return false;
        }
        Swal.fire({
            title: "อัพเดตประเภทโครงการ",
            text: 'ยืนยันการแก้ไขประเภทโครงการ',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'ตกลง',
            cancelButtonText: 'ยกเลิก'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: "./function/update_project_type.php",
                    method: 'POST',
                    dataType: "json",
                    data: {
                        project_type_id : project_type_id,
                        project_type_name: project_type_name
                    },
                    success: function(res) {
                        console.log(res);
                        if (res.status) {
                            toast('success', "อัพสำเร็จ", res.message);
                            clearForm();
                            setTimeout(() => {
                                window.location.reload();
                                $('#modalProjectType').modal('hide');
                            }, 2000);


                        } else {
                            toast('error', 'ไม่สำเร็จ', res.message);
                        }
                    },
                    error: function(err) {
                        console.log(err);
                        toast('error', 'ผิดพลาด', err.responseText);
                    }
                })
            }
        })

    }
    function addProjectType() {
        const project_type_name = $('#project_type_name').val();
        if (project_type_name == "") {
            toast('warning', 'แจ้งเตือน', 'กรุณากรอกชื่อประเภทโครงการ');
            return false;
        }

        Swal.fire({
            title: "เพิ่มประเภทโครงการ",
            text: 'ยืนยันการเพิ่มประเภทโครงการ',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'ตกลง',
            cancelButtonText: 'ยกเลิก'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: "./function/add_project_type.php",
                    method: 'POST',
                    dataType: "json",
                    data: {
                        project_type_name: project_type_name
                    },
                    success: function(res) {
                        console.log(res);
                        if (res.status) {
                            toast('success', "สำเร็จ", res.message);
                            clearForm();
                            setTimeout(() => {
                                window.location.reload();
                                $('#modalAddProjectType').modal('hide');
                            }, 2000);


                        } else {
                            toast('error', 'ไม่สำเร็จ', res.message);
                        }
                    },
                    error: function(err) {
                        console.log(err);
                        toast('error', 'ผิดพลาด', err.responseText);
                    }
                })
            }
        })
    }
    function delProjectType(project_type_id){
        Swal.fire({
            icon : 'warning',
            title : 'ลบประเภทโครงการ',
            text : 'ต้องการลบประเภทโครงการนี้?',
            showCancelButton : true,
            confirmButtonText : 'ตกลง',
            cancelButtonText : 'ยกเลิก'
        }).then((result)=>{
            if(result.isConfirmed){
                $.ajax({
                    url : `./function/del_project_type.php?project_type_id=${project_type_id}`,
                    method : 'DELETE',
                    dataType : 'JSON',
                    success : function(res){
                        console.log(res);
                        if(res.status){
                            toast('success', 'ลบสำเร็จ', res.message);
                            setTimeout(()=>{
                                window.location.reload();
                            },2000);
                        }else{
                            toast('error', 'ไม่สำเร็จ', res.message);
                        }
                    }
                })
            }
        })
    }
</script>


<?php include dirname(__DIR__) . './template/footer.php'; ?>